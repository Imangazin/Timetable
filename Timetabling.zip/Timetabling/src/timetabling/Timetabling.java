package timetabling;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.util.ArrayList;
/*
The timetabling problem using two-dimensional GA
@ author Nurbek Imangazin
@ COSC 5P74

This is main class to run the system
It sets main parameters for GA
*/
public class Timetabling {
    Data data;
    public static final int POPULATION_SIZE = 200;
    public static final double MUTATION_RATE = 0.3;
    public static final double CROSSOVER_RATE = 0.9;
    public static final int TOURNAMENT_SELECTION_SIZE = 2;
    public static final int ELITES = 1;

    public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException, IOException {
        Timetabling timetabling = new Timetabling();
        timetabling.data = new Data();
        ArrayList<Double> bestfitness = new ArrayList<>();
        ArrayList<Double> averagefitness = new ArrayList<>();
        ArrayList<Integer> generations = new ArrayList<>();
        
        int generationNumber = 0;
        generations.add(generationNumber);
                
        System.out.println("Timetabling Problem using 2-dimensional GA");
        System.out.println("Project for COSC 5P74\nby Nurbek Imangazin"); 
        System.out.println("**************************");
        System.out.println("Initial Population: ");
        
        Operators operators = new Operators(timetabling.data);
        Population population = new Population(Timetabling.POPULATION_SIZE,timetabling.data).sortByFitness();
        bestfitness.add(population.getChromosomes().get(0).getFitness());
        
        DecimalFormat formatter = new DecimalFormat("#0.00000");
        System.out.println("Best fitness: "+formatter.format(population.getChromosomes().get(0).getFitness()));
        System.out.println("Avarage fitness: "+formatter.format(population.getAverageFitness()));
        averagefitness.add(population.getAverageFitness());
        //loop to generate next population          
        while(population.getChromosomes().get(0).numberOfConflicts!=1.0){
            System.out.println("**************************");
            System.out.println("Generation Number: "+ ++generationNumber);
            population = operators.evolveOperators(population).sortByFitness();
            System.out.println("Best fitness: "+formatter.format(population.getChromosomes().get(0).getFitness()));
            System.out.println("Avarage fitness: "+formatter.format(population.getAverageFitness()));
            generations.add(generationNumber);
            bestfitness.add(population.getChromosomes().get(0).getFitness());
            averagefitness.add(population.getAverageFitness());          
        }  
        System.out.println("**************************");
        Charts chart = new Charts("Best and Average Fitness", bestfitness, averagefitness, generations);
        timetabling.printTable(population,generationNumber);
    }
    //prints feasable solution in table
    public void printTable(Population population, int generation){
       System.out.println("\nFeasable solution for Course Timetable for Educational Systems\n"
               + "found in generation "+generation+" and follows as below.");
       System.out.println("\nNumber of rooms: "+data.getNumberOfRooms());
       System.out.println("Number of Events: "+data.getNumberOfEvents());
       System.out.println("Number of students: "+data.getNumberOfStudents());
       System.out.println("Number of timeslots: "+data.getNumberOfTimeSlots()+" (9 hours and 5 days)\n");
       
       printLine();
       System.out.printf("%8s", "RxT");
       for (int i=0; i<data.getNumberOfTimeSlots(); i++){
       System.out.printf("%12s", "Time-"+i);    
       }
       System.out.println();
       printLine();
       for(int i=0; i<data.getNumberOfRooms(); i++){
           System.out.printf("%8s", "Room-"+i);
           for(int j=0; j<data.getNumberOfTimeSlots(); j++){
               if(population.getChromosomes().get(0).table[i][j]!=-1)
               System.out.printf("%12s", "Event-"+population.getChromosomes().get(0).table[i][j]);
               else System.out.printf("%12s", "         ");
           }
           System.out.println();
       }
       printLine();
       System.out.println("\nThe best and average fitnes vs generation chart "
               + "can be found at src/Dataset/char1.png");
    }
    public void printLine (){
        System.out.println("--------------------------------------------------------------"
               + "-----------------------------------------------------------------------"
               + "-----------------------------------------------------------------------"
               + "-----------------------------------------------------------------------"
               + "-----------------------------------------------------------------------"
               + "-----------------------------------------------------------------------"
               + "-----------------------------------------------------------------------"
                + "------------------------------------------------------------");
    }
}
