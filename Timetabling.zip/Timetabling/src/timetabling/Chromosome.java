package timetabling;

/*
This class represents two-dimensional chromosome representation
chromosome: int [][] table;
*/
public class Chromosome {
    int [][] table;
    int numberOfClasses = 0; 
    int numberOfConflicts = 0;// number of conflicts for constraints
    double fitness = -1; // fitness
    boolean isFitnessChange = true;
    Data data;
    public Data getData(){return data;}
    public int [][] getTable (){
        isFitnessChange =   true;
        return table;
    }
    // constructor
    // takes data as a parameter and initialize the chromsome individuals
    public Chromosome(Data data){
        this.data = data;
        table = new int [data.getNumberOfRooms()][data.getNumberOfTimeSlots()];
        int eventId=0;
        for (int i=0; i<table.length; i++){
            for (int j=0; j<table[i].length; j++){
                table[i][j]=eventId++;
                if(eventId==data.getNumberOfEvents()) break;
            }
            if(eventId==data.getNumberOfEvents()) break;
        }
        for(int i=1; i<table.length; i++){
            for(int j=0; j<table[i].length; j++){
                if(table[i][j]==0) table[i][j]=-1;
            }
        }
        
        for (int i=0; i<table.length; i++){
            for (int j=0; j<table[i].length; j++){
                int row = (int) (Math.random() * table.length);
                int col = (int) (Math.random() * table[i].length);
                int temp = table[i][j];
                table[i][j]=table[row][col];
                table[row][col]=temp;
            }
        }
    }
    public void setTable (int [][] table){
        this.table=table;
    }
    //method for calculating fitness value
    public double fitness(){
        numberOfConflicts =0;
        for (int i=0; i<table.length; i++){
            for (int j=0; j< table[i].length; j++){
              if(table[i][j]!=-1){
                if(data.getEvents().get(table[i][j]).getNumberOfStudents() > 
                        data.getRooms().get(i).getCapacity() )
                    numberOfConflicts++;
                
                if(data.getRooms().get(i).getFeatures().containsAll(data.getEvents().get(table[i][j]).getFeatures()))
                    numberOfConflicts++;
              }
            }
        }       
        return 1/(double)(numberOfConflicts+1);
    }
    
    public double getFitness(){
       if(isFitnessChange==true){
            fitness = fitness();
            isFitnessChange = false; 
        }
        return fitness;
    }
}
