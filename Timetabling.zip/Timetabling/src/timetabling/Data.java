package timetabling;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
/*
This class handles loading initial datasets from text files
and assigns it to appritiate variables 
*/
public class Data {
    private ArrayList<Events>     events = new ArrayList<>();
    private ArrayList<Rooms>       rooms = new ArrayList<>(); 
    private ArrayList<Features> features = new ArrayList<>(); 
    private ArrayList<Times>       times = new ArrayList<>();
    private ArrayList<Students> students = new ArrayList<>();
    private int numberOfEvents;
    private int numberOfRooms;
    private int numberOfFeatures;
    private int numberOfStudents;
    private int numberOfTimeSlots = 45;
    private int [][] studentEvent;
    private int [][] roomFeature;
    private int [][] eventFeature;
    public ArrayList<Events> getEvents(){return events;}        
    public ArrayList<Rooms> getRooms(){return rooms;}        
    public ArrayList<Features> getFeatures(){return features;}        
    public ArrayList<Times> getTimes(){return times;}        
    public ArrayList<Students> getStudents(){return students;}  
    public int getNumberOfEvents (){return numberOfEvents;}
    public int getNumberOfRooms (){return numberOfRooms;}
    public int getNumberOfFeatures (){return numberOfFeatures;}
    public int getNumberOfStudents (){return numberOfStudents;}
    public int getNumberOfTimeSlots (){return numberOfTimeSlots;}
    public int [][] getStudentEvent (){return studentEvent;}
    public int [][] getRoomFeature (){return roomFeature;}
    public int [][] getEventFeature (){return eventFeature;}
    public Data (){ initialize();}
    public Data initialize (){
      try {
        File dataSet = new File("src/Dataset/competition01.tim"); 
        Scanner s = new Scanner(dataSet);
        numberOfEvents = s.nextInt();
        numberOfRooms = s.nextInt();
        numberOfFeatures = s.nextInt();
        numberOfStudents = s.nextInt();
        studentEvent = new int [numberOfStudents][numberOfEvents];
        roomFeature = new int[numberOfRooms][numberOfFeatures];
        eventFeature = new int[numberOfEvents][numberOfFeatures];
        
        for(int i=0; i<numberOfEvents; i++){
            Events newEvent = new Events(i);
            events.add(newEvent);
        }
        for(int i=0; i<numberOfRooms; i++){
            Rooms newRoom = new Rooms(i, s.nextInt());
            rooms.add(newRoom);
        }
        for(int i=0; i<numberOfFeatures; i++){
            Features newFeature = new Features(i);
            features.add(newFeature);
        }
        for(int i=0; i<numberOfStudents; i++){
            Students newStudent = new Students(i);
            students.add(newStudent);
        }
        
        for(int i=0; i<numberOfTimeSlots; i++){
            Times newTime = new Times(i);
            times.add(newTime);
        }
        
        for(int i=0; i<numberOfStudents; i++){
            for(int j=0; j<numberOfEvents; j++){
                studentEvent[i][j]=s.nextInt();
            }
        }
       
        for(int i=0; i<numberOfRooms; i++){
            for(int j=0; j<numberOfFeatures; j++){
                roomFeature[i][j] = s.nextInt();
            }
        }
       
        for(int i=0; i<numberOfEvents; i++){
            for(int j=0; j<numberOfFeatures; j++){
                eventFeature[i][j]=s.nextInt();
            }
        }
        
        for(int i=0; i<numberOfEvents; i++){
            events.get(i).setStudents(studentsForEachevent(i));            
            events.get(i).setFeatures(featuresForEachEvent(i));
        }
        for(int i=0; i<numberOfRooms; i++){
            rooms.get(i).setFeatures(featuresForEachRoom(i));
        }
        
      }catch (Exception e){
          return null;
      }
        return this;       
    }
    
    public ArrayList<Integer> studentsForEachevent(int event){
        ArrayList<Integer> students = new ArrayList<>();
        for (int i=0; i<numberOfStudents; i++){
           if(studentEvent[i][event]==1) students.add(i);
        }
        return students;
    }
    public ArrayList<Integer> featuresForEachEvent(int event){
        ArrayList<Integer> features = new ArrayList<>();
        for (int i=0; i<numberOfFeatures; i++){
            if(eventFeature[event][i]==1) features.add(i);
        }
        return features;
    }
    public ArrayList<Integer> featuresForEachRoom (int room){
        ArrayList<Integer> features = new ArrayList<>();
        for (int i=0; i<numberOfRooms; i++){
            if(roomFeature[room][i]==1) features.add(i);
        }
        return features;
    }
}
