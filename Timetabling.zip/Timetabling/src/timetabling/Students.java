package timetabling;
/*
Student class, includes all info about a student
*/
public class Students {
    private int id;
    public int getId(){return id;}
    public Students(int id){
        this.id = id;
    }
}
