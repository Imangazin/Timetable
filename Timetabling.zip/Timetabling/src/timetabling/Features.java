package timetabling;
/*
Feature class, includes all info about a feature
*/
public class Features {
    private int id;
    public int getId (){return id;}
    public Features (int id){
        this.id = id;
    }
}
