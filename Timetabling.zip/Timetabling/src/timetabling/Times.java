package timetabling;
/*
Time class, includes all info about a timeslot
*/
public class Times {
   private int id;
   public int getId() {return id;} 
   public Times (int id){
       this.id=id;
   }
}
