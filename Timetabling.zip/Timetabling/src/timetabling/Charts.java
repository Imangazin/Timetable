package timetabling;

import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;


/*
This class draws a chart Best vs Average fitnes,
and saves as *.png image file located at "src/Dataset/chart1.png"


This class was adopted from sourse:
***********************************************
- Author(s) name: www.codejava.net
- 21 November 2017
- Using JFreechart to draw XY line chart with XYDataset
- sourse code
- http://www.codejava.net/java-se/graphics/using-jfreechart-to-draw-xy-line-chart-with-xydataset
***********************************************
*/

public class Charts extends ApplicationFrame {

    public Charts(String title,ArrayList<Double> bFitness, ArrayList<Double> aFitness, 
                                                             ArrayList<Integer> generations) throws IOException {
      super(title);
      final XYDataset dataset = createDataset(bFitness, aFitness, generations);
      final JFreeChart chart = createChart(dataset);      
      int width = 640;   /* Width of the image */
      int height = 480;  /* Height of the image */ 
      File XYChart = new File( "src/Dataset/chart1.png" ); 
      ChartUtilities.saveChartAsPNG( XYChart, chart, width, height);
    }
    //creates dataset for chart
    //takes best and average fitnes values, and generation number
    //and adds as separate series of line
    private XYSeriesCollection createDataset(ArrayList<Double> bFitness, ArrayList<Double> aFitness, 
                                                             ArrayList<Integer> generations) {      
        final XYSeries bestFitnes = new XYSeries ("Best Fitness");
        for(int i=0; i< bFitness.size(); i++){
            bestFitnes.add(generations.get(i), bFitness.get(i));
        }
        
        final XYSeries averageFitnes = new XYSeries ("Average Fitness");
        for(int i=0; i< aFitness.size(); i++){
            averageFitnes.add(generations.get(i), aFitness.get(i));
        }
        
        final XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(bestFitnes);
        dataset.addSeries(averageFitnes);
        
        return dataset;
    }
//creates chart using dataSets
    //and sets properties of plot and each line
    private JFreeChart createChart(XYDataset dataset) {
        final JFreeChart chart = ChartFactory.createXYLineChart(
                "", 
                "Generations", "Fitness", 
                dataset, 
                PlotOrientation.VERTICAL, 
                true,
                true,
                false);
        chart.setBackgroundPaint(Color.white);
        final XYPlot plot = chart.getXYPlot();
        plot.setBackgroundPaint(Color.lightGray);
        plot.setDomainGridlinePaint(Color.white);
        plot.setRangeGridlinePaint(Color.white);
        final XYLineAndShapeRenderer renderer= new XYLineAndShapeRenderer();     
        renderer.setSeriesLinesVisible(0,true);
        renderer.setSeriesLinesVisible(1,true);     
        renderer.setSeriesShapesVisible(0,false);
        renderer.setSeriesShapesVisible(1,false);  
        renderer.setSeriesPaint(0,Color.RED);
        renderer.setSeriesPaint(1,Color.BLUE);
        plot.setRenderer(renderer);
        final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());       
        return chart;
    }
}
