package timetabling;

import java.util.ArrayList;
/*
Operators class, handles all GA operators such as: crossover and mutation
and tournament selection
*/
public class Operators {
   Data data;
   public Operators (Data data){
       this.data = data;
   }
   //combined method for crossover and mutation operator
   public Population evolveOperators(Population population){
       return mutatePopulation(crosPopulation(population));
   }
   //one point two-dimensional crossover operator 
   //takes two chromosomes and returns two child chromosomes
   public Chromosome [] crosChromosome(Chromosome parent1, Chromosome parent2){
       int [][] child1 = new int [parent1.data.getNumberOfRooms()][parent1.data.getNumberOfTimeSlots()];
       int [][] child2 = new int [parent2.data.getNumberOfRooms()][parent2.data.getNumberOfTimeSlots()];
       
       int rowR = (int) (Math.random()*child1.length);
       int colR = (int) (Math.random()*child1[rowR].length);
       int colRR = colR;
       
       ArrayList<Integer> child1Till = new ArrayList<>();
       ArrayList<Integer> child2Till = new ArrayList<>();
       ArrayList<Integer> child1Head = new ArrayList<>();
       ArrayList<Integer> child2Head = new ArrayList<>();
       
       for(int i=rowR; i<child1.length; i++){
           for(int j=colR; j<child1[i].length; j++){
               child1[i][j]=parent2.getTable()[i][j];
               child2[i][j]=parent1.getTable()[i][j];
               child1Till.add(parent2.getTable()[i][j]);
               child2Till.add(parent1.getTable()[i][j]);
           }
           colR=0;
       }
       
       for(int i=0; i<child1.length; i++){
           for(int j=0; j<child1[i].length; j++){
               
               if(parent1.getTable()[i][j]!=-1){
                   if(!child1Till.contains(parent1.getTable()[i][j]))
                       child1Head.add(parent1.getTable()[i][j]);
               } //else child1Head.add(-1);
               
               if(parent2.getTable()[i][j]!=-1){
                   if(!child2Till.contains(parent2.getTable()[i][j]))
                       child2Head.add(parent2.getTable()[i][j]);
               } //else child2Head.add(-1);
           }
       }
       
       int row=0; int col=0;
       for (int i=0; i<=rowR; i++){
           for(int j=0; j<child1[i].length; j++){
               if(i==rowR && j==colRR) break;
               
               if(row<child1Head.size()) child1[i][j]=child1Head.get(row++);
               else child1[i][j]=-1;
               
               if(col<child2Head.size()) child2[i][j]=child2Head.get(col++);
               else child2[i][j]=-1;
           }   
       }
       
       Chromosome [] child = new Chromosome [2];
       Chromosome childChromosome1 = new Chromosome (data);
       Chromosome childChromosome2 = new Chromosome (data);
       childChromosome1.setTable(child1);
       childChromosome2.setTable(child2);
       child[0] = childChromosome1;
       child[1] = childChromosome2;
    return child;
   }
   //two point mutation operator
   //takes an chromosome and returns mutated chromosome
   public Chromosome mutateChromosome (Chromosome chromosome){
       
       
       int fstRowR = (int)(Math.random()*chromosome.getTable().length);
       int fstColR = (int)(Math.random()*chromosome.getTable()[fstRowR].length);
       
       int sndRowR = (int) (Math.random() * chromosome.getTable().length);
       int sndColR = (int) (Math.random() * chromosome.getTable()[sndRowR].length);
       
       for(int i=0; i<chromosome.getTable().length; i++){
           for(int j=0; j<chromosome.getTable()[i].length; j++){
               if(Timetabling.MUTATION_RATE>Math.random()) {
                   int temp = chromosome.getTable()[fstRowR][fstColR];
                   chromosome.getTable()[fstRowR][fstColR] = chromosome.getTable()[sndRowR][sndColR];
                   chromosome.getTable()[sndRowR][sndColR] = temp;
               }
           }
       } 
       return chromosome;
   }
   //tournament selection method
   public Population tournament (Population population){
       Population tournamentPopulation = new Population (Timetabling.TOURNAMENT_SELECTION_SIZE, data);
       for(int i=0; i<Timetabling.TOURNAMENT_SELECTION_SIZE; i++){
           tournamentPopulation.getChromosomes().set(i, 
                   population.getChromosomes().get((int)Math.random()*population.getChromosomes().size()));
       }
       return tournamentPopulation;
   }
   
   // mutation method for all chromosomes in population
   public Population mutatePopulation(Population population){
       Population mutatePopulation = new Population(Timetabling.POPULATION_SIZE,data);
       
       for(int i=0; i<Timetabling.ELITES; i++){
           mutatePopulation.getChromosomes().set(i, population.getChromosomes().get(i));
       }
       for(int i=Timetabling.ELITES; i<population.getChromosomes().size(); i++){
           mutatePopulation.getChromosomes().set(i, mutateChromosome(population.getChromosomes().get(i)));
       }
       return mutatePopulation;
   }
   
   //crossover method for all chromosomes in population
   public Population crosPopulation (Population population){
       Population crosPopulation = new Population (population.getChromosomes().size(),data);
       for(int i=0; i<Timetabling.ELITES; i++){
           crosPopulation.getChromosomes().set(i, population.getChromosomes().get(i));
       }
      
       for (int i=Timetabling.ELITES; i<population.getChromosomes().size()-1; i=i+2){
           if(Timetabling.CROSSOVER_RATE>Math.random()){
               Chromosome chromosome1 = tournament(population).sortByFitness().getChromosomes().get(0);
               Chromosome chromosome2 = tournament(population).sortByFitness().getChromosomes().get(0);
               Chromosome [] newChromosomes = crosChromosome(chromosome1, chromosome2);
               crosPopulation.getChromosomes().set(i, newChromosomes[0]);
               crosPopulation.getChromosomes().set(i+1, newChromosomes[1]);
           }else {crosPopulation.getChromosomes().set(i, population.getChromosomes().get(i));
                  crosPopulation.getChromosomes().set(i+1, population.getChromosomes().get(i+1));  
           }
       }
       return crosPopulation;
   }
}
