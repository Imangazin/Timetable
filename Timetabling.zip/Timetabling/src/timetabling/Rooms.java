package timetabling;

import java.util.ArrayList;
/*
Rooms class, includes all info about an each room
including capacity, id, and features of the room
*/
public class Rooms {
    private int id;
    private int capacity;
    private ArrayList<Integer> features;
    public int getCapacity() {return capacity;}
    public int getId() {return id;}
    public ArrayList<Integer> getFeatures(){return features;}
    public Rooms (int id, int capacity) {
        this.id = id;
        this.capacity = capacity;
    }
    public void setFeatures(ArrayList<Integer> features){
        this.features = features;
    }
}
