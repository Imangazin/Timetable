package timetabling;

import java.util.ArrayList;
/*
Event class, includes all info about an event
*/
public class Events {
    private int id;
    private int numberOfStudents;
    private ArrayList<Integer> students;
    private ArrayList<Integer> features;
    public ArrayList<Integer> getFeatures(){return features;}
    public int getNumberOfStudents (){return numberOfStudents;}
    public ArrayList<Integer> getStudents(){return students;}
    public int getId(){return id;}
    public Events(int id){
        this.id = id;
    }
    public void setStudents (ArrayList<Integer> students){
        this.students = students;
        this.numberOfStudents = students.size();
    }
    public void setFeatures(ArrayList<Integer> features){
        this.features = features;
    }
}
