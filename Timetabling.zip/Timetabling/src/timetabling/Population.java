package timetabling;

import java.util.ArrayList;
/*
class Population handles population of chromosomes
It takes size of the population and initializes the population
*/
public class Population {
    ArrayList<Chromosome> chromosomes;
    public Population (int size, Data data){
        chromosomes = new ArrayList<Chromosome>(size);
        for(int i=0; i<size; i++){
            chromosomes.add(new Chromosome(data));
        }
    }
    
    public ArrayList<Chromosome> getChromosomes(){return this.chromosomes;}
    //Sorts the population based on fitness value of each chromosome
    //Then 0s element (chromosome) will be the best individual in the current population
    public Population sortByFitness(){
        chromosomes.sort((chromosome1, chromosome2)->{
            int res = 0;
            if(chromosome1.getFitness()>chromosome2.getFitness()) res =-1;
            else if(chromosome1.getFitness()<chromosome2.getFitness()) res = 1;
            return res;
        });
        return this;
    }
    //calculates average fitness value
    public double getAverageFitness(){
        double averageFitness=0;
        for (int i=0; i<chromosomes.size();i++){
            averageFitness+=chromosomes.get(i).getFitness();
        }
        averageFitness = averageFitness/chromosomes.size();
        return averageFitness;
    }
}
