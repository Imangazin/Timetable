package timetabling;
/*
Method class contains all information for one class
*/
public class Class {
    private final int id;
    private final Events event;
    private Rooms room;
    private Features features;
    private Times time;
    private int [][] table;
    public Class(int id, Events event, Data data){
        this.id = id;
        this.event = event;
    }
    public void setRoom(Rooms room){
        this.room = room;
    }
    public void setTime(Times time){
        this.time = time;
    }
    public int getId(){return id;} 
    public Events getEvent(){return event;}
    public Rooms getRoom(){return room;}
    public Times getTimes(){return time;}
    public int [][] getTable(){return table;}
}
